# ShopEasy - Django E-commerce Store

## Features
- Product listing and details
- Shopping cart using Django sessions
- User registration, login and logout
- Checkout and order processing
- Stock reduction after order
- My Orders page
- SQLite database
- Django Admin for products and orders

## Run
1. Install Python 3.10+.
2. Open terminal in this folder.
3. Create virtual environment:
   `python -m venv venv`
4. Activate:
   Windows: `venv\Scripts\activate`
5. Install:
   `pip install -r requirements.txt`
6. Create database:
   `python manage.py makemigrations`
   `python manage.py migrate`
7. Create admin:
   `python manage.py createsuperuser`
8. Start:
   `python manage.py runserver`
9. Open http://127.0.0.1:8000/
10. Admin: http://127.0.0.1:8000/admin/

Add products from Django Admin. Use image URLs from publicly accessible images.
