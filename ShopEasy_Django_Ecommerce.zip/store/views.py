from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User
from django.db import transaction
from .models import Product,Order,OrderItem

def home(request):
    products=Product.objects.all().order_by("-created_at")
    return render(request,"store/home.html",{"products":products})

def product_detail(request,pk):
    return render(request,"store/product_detail.html",{"product":get_object_or_404(Product,pk=pk)})

def add_to_cart(request,pk):
    product=get_object_or_404(Product,pk=pk)
    cart=request.session.get("cart",{})
    key=str(pk); qty=cart.get(key,0)
    if qty < product.stock: cart[key]=qty+1
    else: messages.error(request,"Not enough stock available.")
    request.session["cart"]=cart
    messages.success(request,f"{product.name} added to cart.")
    return redirect(request.META.get("HTTP_REFERER","cart"))

def remove_from_cart(request,pk):
    cart=request.session.get("cart",{}); cart.pop(str(pk),None); request.session["cart"]=cart
    return redirect("cart")

def cart(request):
    cart_data=request.session.get("cart",{}); items=[]; total=0
    for pid,qty in cart_data.items():
        p=get_object_or_404(Product,pk=pid)
        subtotal=p.price*qty; total+=subtotal
        items.append({"product":p,"quantity":qty,"subtotal":subtotal})
    return render(request,"store/cart.html",{"items":items,"total":total})

@login_required
def checkout(request):
    cart_data=request.session.get("cart",{})
    if not cart_data: messages.warning(request,"Your cart is empty."); return redirect("cart")
    items=[]; total=0
    for pid,qty in cart_data.items():
        p=get_object_or_404(Product,pk=pid)
        if qty>p.stock: messages.error(request,f"Only {p.stock} units of {p.name} are available."); return redirect("cart")
        total+=p.price*qty; items.append((p,qty))
    if request.method=="POST":
        address=request.POST.get("address","").strip(); phone=request.POST.get("phone","").strip()
        if not address or not phone: messages.error(request,"Please enter address and phone."); return render(request,"store/checkout.html",{"items":items,"total":total})
        with transaction.atomic():
            order=Order.objects.create(user=request.user,total_amount=total,address=address,phone=phone)
            for p,qty in items:
                OrderItem.objects.create(order=order,product=p,quantity=qty,price=p.price)
                p.stock-=qty; p.save(update_fields=["stock"])
        request.session["cart"]={}
        messages.success(request,f"Order #{order.id} placed successfully!")
        return redirect("orders")
    return render(request,"store/checkout.html",{"items":items,"total":total})

@login_required
def orders(request):
    return render(request,"store/orders.html",{"orders":Order.objects.filter(user=request.user).prefetch_related("items").order_by("-created_at")})

def register_view(request):
    if request.method=="POST":
        username=request.POST.get("username","").strip(); email=request.POST.get("email","").strip(); password=request.POST.get("password","")
        if not username or not password: messages.error(request,"Username and password are required.")
        elif User.objects.filter(username=username).exists(): messages.error(request,"Username already exists.")
        else:
            user=User.objects.create_user(username=username,email=email,password=password); login(request,user); return redirect("home")
    return render(request,"store/register.html")

def login_view(request):
    if request.method=="POST":
        user=authenticate(username=request.POST.get("username"),password=request.POST.get("password"))
        if user: login(request,user); return redirect(request.GET.get("next","home"))
        messages.error(request,"Invalid username or password.")
    return render(request,"store/login.html")

def logout_view(request): logout(request); return redirect("home")
