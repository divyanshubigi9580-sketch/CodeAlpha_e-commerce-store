from django.contrib import admin
from .models import Product,Order,OrderItem
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display=("name","price","stock","category","created_at")
    search_fields=("name","category")
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display=("id","user","total_amount","status","created_at")
    list_filter=("status",)
    search_fields=("user__username",)
@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display=("order","product","quantity","price")
