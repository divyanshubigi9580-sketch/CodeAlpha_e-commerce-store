from django.db import models
from django.contrib.auth.models import User

class Product(models.Model):
    name=models.CharField(max_length=200)
    description=models.TextField()
    price=models.DecimalField(max_digits=10,decimal_places=2)
    image=models.URLField(blank=True)
    stock=models.PositiveIntegerField(default=10)
    category=models.CharField(max_length=100,default="General")
    created_at=models.DateTimeField(auto_now_add=True)
    def __str__(self): return self.name

class Order(models.Model):
    STATUS_CHOICES=[("Pending","Pending"),("Processing","Processing"),("Shipped","Shipped"),("Delivered","Delivered"),("Cancelled","Cancelled")]
    user=models.ForeignKey(User,on_delete=models.CASCADE,related_name="orders")
    total_amount=models.DecimalField(max_digits=10,decimal_places=2)
    status=models.CharField(max_length=20,choices=STATUS_CHOICES,default="Pending")
    address=models.TextField()
    phone=models.CharField(max_length=20)
    created_at=models.DateTimeField(auto_now_add=True)
    def __str__(self): return f"Order #{self.id} - {self.user.username}"

class OrderItem(models.Model):
    order=models.ForeignKey(Order,on_delete=models.CASCADE,related_name="items")
    product=models.ForeignKey(Product,on_delete=models.SET_NULL,null=True)
    quantity=models.PositiveIntegerField()
    price=models.DecimalField(max_digits=10,decimal_places=2)
    def subtotal(self): return self.quantity*self.price
